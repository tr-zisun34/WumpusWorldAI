import pysat
# pysat.params['data_dirs'] = '~/pysatData'
from Graphic import *
from EnhancedGraphic import *

# app = Graphic()
app = EnhancedGraphic()
app.run()
